import React from "react";
import {
  AbsoluteFill,
  Audio,
  Easing,
  Img,
  Sequence,
  interpolate,
  staticFile,
} from "remotion";
import { useAuthoredFrame, useAuthoredFrames } from "./timing";

// Adapted from Nutlope/inspo teaser: authored 30fps timeline, 60fps render,
// typed opening with press/zoom handoff, scene sequences and synced SFX.
const C = {
  paper: "#f5efe4",
  white: "#fffaf2",
  ink: "#122b26",
  muted: "#50625c",
  mint: "#cad8c3",
  coral: "#c76f56",
  lime: "#c8d69b",
  gold: "#d4af37",
};
const ease = Easing.bezier(0.16, 1, 0.3, 1);
const tween = (f: number, a: number, b: number, x = 0, y = 1) =>
  interpolate(f, [a, b], [x, y], {
    extrapolateLeft: "clamp",
    extrapolateRight: "clamp",
    easing: ease,
  });
const display = {
  fontFamily: "Outfit",
  fontWeight: 600,
  letterSpacing: "-.045em",
  lineHeight: 1.04,
} as const;
const Label: React.FC<{ children: React.ReactNode; light?: boolean }> = ({
  children,
  light,
}) => (
  <div
    style={{
      fontSize: 21,
      fontWeight: 600,
      letterSpacing: 3,
      textTransform: "uppercase",
      color: light ? C.lime : C.muted,
    }}
  >
    {children}
  </div>
);
const Brand: React.FC<{ large?: boolean; light?: boolean }> = ({
  large,
  light,
}) => (
  <div style={{ display: "flex", alignItems: "center", gap: large ? 22 : 12 }}>
    <Img
      src={staticFile("pathway-mark.svg")}
      style={{ width: large ? 118 : 60 }}
    />
    <div>
      <div
        style={{
          ...display,
          fontSize: large ? 94 : 33,
          color: light ? C.paper : C.ink,
        }}
      >
        Pathway
      </div>
      <div
        style={{
          fontSize: large ? 19 : 10,
          letterSpacing: large ? 6 : 3,
          marginTop: 7,
          color: light ? C.mint : C.muted,
        }}
      >
        LANGUAGE SOLUTIONS
      </div>
    </div>
  </div>
);
const Shell: React.FC<{
  children: React.ReactNode;
  dark?: boolean;
  step: string;
}> = ({ children, dark, step }) => (
  <AbsoluteFill
    style={{
      background: dark ? C.ink : C.paper,
      color: dark ? C.paper : C.ink,
      padding: "56px 88px",
    }}
  >
    <div
      style={{
        display: "flex",
        justifyContent: "space-between",
        alignItems: "center",
      }}
    >
      <Brand light={dark} />
      <div style={{ fontSize: 19, letterSpacing: 2, opacity: 0.65 }}>
        {step}
      </div>
    </div>
    {children}
    <div
      style={{
        position: "absolute",
        bottom: 42,
        left: 88,
        right: 88,
        display: "flex",
        justifyContent: "space-between",
        fontSize: 17,
        letterSpacing: 1.5,
        opacity: 0.62,
      }}
    >
      <span>FRANCÉS · TEF / TCF CANADA</span>
      <span>pathway-languages.com</span>
    </div>
  </AbsoluteFill>
);
const Reveal: React.FC<{
  children: React.ReactNode;
  at?: number;
  style?: React.CSSProperties;
}> = ({ children, at = 0, style }) => {
  const f = useAuthoredFrame();
  return (
    <div
      style={{
        opacity: tween(f, at, at + 18),
        transform: `translateY(${tween(f, at, at + 25, 38, 0)}px)`,
        ...style,
      }}
    >
      {children}
    </div>
  );
};

const Opening = () => {
  const f = useAuthoredFrame();
  const prompt = "Quiero alcanzar el NCLC 7.";
  const typed = prompt.slice(0, Math.floor(f * 1.1));
  return (
    <Shell step="TU OBJETIVO">
      <AbsoluteFill
        style={{
          alignItems: "center",
          justifyContent: "center",
          transform: `scale(${tween(f, 88, 102, 1, 1.15)})`,
          opacity: 1 - tween(f, 94, 102),
        }}
      >
        <Label>Todo empieza con una meta.</Label>
        <div
          style={{ ...display, fontSize: 104, marginTop: 35, marginBottom: 60 }}
        >
          Tu francés. Tu próximo paso.
        </div>
        <div
          style={{
            width: 1330,
            height: 144,
            background: C.white,
            border: "1px solid #122b2625",
            borderRadius: 80,
            display: "flex",
            alignItems: "center",
            padding: "0 24px 0 54px",
            boxShadow: "0 26px 70px #122b2610",
            transform: `scale(${interpolate(f, [74, 78, 83], [1, 0.975, 1], { extrapolateLeft: "clamp", extrapolateRight: "clamp" })})`,
          }}
        >
          <span style={{ fontSize: 45, flex: 1 }}>
            {typed}
            <span
              style={{
                opacity: f < 25 || Math.floor(f / 9) % 2 === 0 ? 1 : 0,
                color: C.coral,
              }}
            >
              │
            </span>
          </span>
          <div
            style={{
              width: 92,
              height: 92,
              borderRadius: 50,
              background: C.ink,
              color: C.paper,
              display: "grid",
              placeItems: "center",
              fontSize: 50,
            }}
          >
            →
          </div>
        </div>
        <Reveal at={38} style={{ fontSize: 27, color: C.muted, marginTop: 34 }}>
          Un plan que sí cabe en tu vida.
        </Reveal>
      </AbsoluteFill>
    </Shell>
  );
};

const Assessment = () => {
  const f = useAuthoredFrame();
  return (
    <Shell step="01 / CONOCE TU PUNTO DE PARTIDA">
      <div
        style={{ display: "flex", alignItems: "center", height: 780, gap: 95 }}
      >
        <div style={{ width: 720 }}>
          <Reveal>
            <Label>Evaluación inicial</Label>
            <h1 style={{ ...display, fontSize: 100, margin: "28px 0" }}>
              Primero,
              <br />
              sabemos
              <br />
              <span style={{ color: C.coral }}>dónde estás.</span>
            </h1>
          </Reveal>
          <Reveal
            at={18}
            style={{
              fontSize: 31,
              lineHeight: 1.45,
              maxWidth: 610,
              color: C.muted,
            }}
          >
            Tu nivel, tu disponibilidad
            <br />y tu fecha objetivo.
          </Reveal>
        </div>
        <Reveal
          at={8}
          style={{
            width: 825,
            background: C.white,
            padding: 48,
            borderRadius: 28,
            border: "1px solid #122b2620",
            boxShadow: "0 28px 75px #122b2610",
          }}
        >
          <div
            style={{
              display: "flex",
              justifyContent: "space-between",
              marginBottom: 38,
            }}
          >
            <span style={{ ...display, fontSize: 36 }}>
              Tu punto de partida
            </span>
            <span style={{ fontSize: 18, color: C.muted }}>EJEMPLO</span>
          </div>
          {[
            ["Comprensión escrita", "B1", 0.7],
            ["Comprensión oral", "A2", 0.44],
            ["Gramática y vocabulario", "B1", 0.68],
          ].map(([name, level, n], i) => (
            <div key={name} style={{ marginTop: 27 }}>
              <div
                style={{
                  display: "flex",
                  justifyContent: "space-between",
                  fontSize: 26,
                  marginBottom: 13,
                }}
              >
                <span>{name}</span>
                <b>{level}</b>
              </div>
              <div
                style={{ height: 11, background: "#e6e9df", borderRadius: 10 }}
              >
                <div
                  style={{
                    height: 11,
                    width: `${Number(n) * 100 * tween(f, 20 + i * 9, 55 + i * 9)}%`,
                    background: i === 1 ? C.coral : C.ink,
                    borderRadius: 10,
                  }}
                />
              </div>
            </div>
          ))}
          <Reveal
            at={58}
            style={{
              marginTop: 38,
              padding: 23,
              background: C.mint,
              borderRadius: 13,
              fontSize: 23,
            }}
          >
            Prioridad: comprensión oral.
          </Reveal>
          <div style={{ marginTop: 20, fontSize: 18, color: C.muted }}>
            La expresión oral se confirma en clase.
          </div>
        </Reveal>
      </div>
    </Shell>
  );
};

const Route = () => {
  const f = useAuthoredFrame();
  return (
    <Shell dark step="02 / UNA RUTA PERSONALIZADA">
      <Reveal style={{ textAlign: "center", marginTop: 75 }}>
        <Label light>Tu recorrido</Label>
        <h1 style={{ ...display, fontSize: 96, margin: "22px 0 15px" }}>
          Cada paso tiene un propósito.
        </h1>
        <div style={{ fontSize: 29, color: C.mint }}>
          Un recorrido desde tu nivel, hacia tu objetivo.
        </div>
      </Reveal>
      <div style={{ display: "flex", gap: 24, marginTop: 66 }}>
        {["A1", "A2", "B1", "B2"].map((level, i) => (
          <div
            key={level}
            style={{
              flex: 1,
              height: 354,
              padding: "35px 35px",
              borderRadius: 22,
              background: i === 3 ? C.lime : i === 2 ? C.mint : C.white,
              color: C.ink,
              transform: `translateY(${tween(f, 10 + i * 8, 40 + i * 8, 170, 0)}px) rotate(${tween(f, 10 + i * 8, 40 + i * 8, (i - 1.5) * 5, 0)}deg)`,
              opacity: tween(f, 10 + i * 8, 28 + i * 8),
              position: "relative",
            }}
          >
            <Label>PROGRAMA</Label>
            <div style={{ ...display, fontSize: 135, marginTop: 28 }}>
              {level}
            </div>
            <div style={{ fontSize: 23, marginTop: 23 }}>
              {
                [
                  "Primeros pasos",
                  "Una base sólida",
                  "Más autonomía",
                  "Preparación TEF / TCF",
                ][i]
              }
            </div>
          </div>
        ))}
      </div>
      <Reveal
        at={62}
        style={{
          display: "flex",
          alignItems: "center",
          gap: 22,
          marginTop: 39,
          fontSize: 26,
        }}
      >
        <span style={{ height: 2, background: C.gold, flex: 1 }} />
        <span>OBJETIVO NCLC 7 · CUATRO COMPETENCIAS</span>
        <span style={{ height: 2, background: C.gold, flex: 1 }} />
      </Reveal>
    </Shell>
  );
};

const Week = () => {
  const f = useAuthoredFrame();
  return (
    <Shell step="03 / ACOMPAÑAMIENTO REAL">
      <Reveal style={{ marginTop: 83 }}>
        <Label>Una semana con Pathway</Label>
        <h1 style={{ ...display, fontSize: 96, margin: "22px 0 40px" }}>
          Entre una clase y la siguiente,
          <br />
          <span style={{ color: C.coral }}>sigues avanzando.</span>
        </h1>
      </Reveal>
      <div style={{ display: "flex", gap: 22, marginTop: 25 }}>
        {[
          {
            day: "LUNES",
            title: "Clase privada",
            text: "En vivo, con tu profesor.",
            bg: C.ink,
            fg: C.paper,
          },
          {
            day: "MARTES",
            title: "Práctica guiada",
            text: "Una prioridad clara.",
            bg: C.mint,
            fg: C.ink,
          },
          {
            day: "MIÉRCOLES",
            title: "Feedback útil",
            text: "Sabes qué mejorar.",
            bg: C.white,
            fg: C.ink,
          },
          {
            day: "JUEVES",
            title: "Vuelve a hablar",
            text: "Practica y recibe correcciones.",
            bg: C.coral,
            fg: C.white,
          },
        ].map((card, i) => (
          <div
            key={card.day}
            style={{
              flex: 1,
              height: 300,
              padding: 30,
              borderRadius: 20,
              background: card.bg,
              color: card.fg,
              opacity: tween(f, 12 + i * 11, 27 + i * 11),
              transform: `translateY(${tween(f, 12 + i * 11, 40 + i * 11, 65, 0)}px)`,
            }}
          >
            <div style={{ fontSize: 20, letterSpacing: 2, opacity: 0.75 }}>
              {card.day}
            </div>
            <div
              style={{ ...display, fontSize: 44, marginTop: 53, minHeight: 92 }}
            >
              {card.title}
            </div>
            <div style={{ fontSize: 23, lineHeight: 1.4, marginTop: 24 }}>
              {card.text}
            </div>
          </div>
        ))}
      </div>
      <Reveal
        at={66}
        style={{
          display: "flex",
          justifyContent: "space-between",
          marginTop: 45,
          fontSize: 24,
          color: C.muted,
        }}
      >
        <span>Clases privadas · Seguimiento · Simulacros</span>
        <span style={{ fontSize: 19 }}>
          Semana ilustrativa; ritmo según evaluación.
        </span>
      </Reveal>
    </Shell>
  );
};

const Website = () => {
  const f = useAuthoredFrame();
  return (
    <Shell step="DESCUBRE PATHWAY">
      <div
        style={{ display: "flex", alignItems: "center", gap: 72, height: 790 }}
      >
        <Reveal style={{ width: 525, flexShrink: 0 }}>
          <Label>Conoce el programa</Label>
          <h1 style={{ ...display, fontSize: 94, margin: "27px 0" }}>
            Una meta.
            <br />
            Un plan.
            <br />
            <span style={{ color: C.coral }}>Tu ritmo.</span>
          </h1>
          <div style={{ fontSize: 29, color: C.muted, lineHeight: 1.5 }}>
            Clases privadas en vivo.
            <br />
            Pago mensual sin permanencia.
          </div>
        </Reveal>
        <div
          style={{
            width: 1050,
            flexShrink: 0,
            transform: `translateY(${tween(f, 0, 35, 90, 0)}px) perspective(2000px) rotateY(${tween(f, 0, 45, -8, 0)}deg)`,
            opacity: tween(f, 0, 18),
            borderRadius: 18,
            overflow: "hidden",
            border: "1px solid #122b2628",
            boxShadow: "0 32px 65px #122b2620",
          }}
        >
          <div
            style={{
              height: 45,
              display: "flex",
              alignItems: "center",
              gap: 10,
              background: C.white,
              padding: "0 23px",
            }}
          >
            {[0, 1, 2].map((i) => (
              <span
                key={i}
                style={{
                  width: 10,
                  height: 10,
                  borderRadius: 10,
                  background: "#cad8c3",
                }}
              />
            ))}
            <span style={{ marginLeft: 22, fontSize: 16, color: C.muted }}>
              pathway-languages.com
            </span>
          </div>
          <Img
            src={staticFile("hero.jpg")}
            style={{ width: "100%", display: "block" }}
          />
        </div>
      </div>
    </Shell>
  );
};

const Outro = () => {
  return (
    <AbsoluteFill
      style={{
        background: C.paper,
        color: C.ink,
        alignItems: "center",
        justifyContent: "center",
      }}
    >
      <Reveal>
        <Brand large />
      </Reveal>
      <Reveal
        at={12}
        style={{ ...display, fontSize: 82, textAlign: "center", marginTop: 55 }}
      >
        Tu objetivo merece
        <br />
        <span style={{ color: C.coral }}>una ruta clara.</span>
      </Reveal>
      <Reveal at={24} style={{ fontSize: 28, color: C.muted, marginTop: 29 }}>
        Empieza con una evaluación gratuita.
      </Reveal>
      <Reveal
        at={34}
        style={{
          marginTop: 39,
          display: "flex",
          alignItems: "center",
          gap: 33,
          padding: "24px 30px 24px 43px",
          background: C.ink,
          color: C.paper,
          borderRadius: 60,
          fontSize: 33,
        }}
      >
        <span>pathway-languages.com</span>
        <span
          style={{
            background: C.lime,
            color: C.ink,
            width: 47,
            height: 47,
            borderRadius: 50,
            display: "grid",
            placeItems: "center",
          }}
        >
          →
        </span>
      </Reveal>
      <div
        style={{
          position: "absolute",
          bottom: 54,
          fontSize: 18,
          color: C.muted,
        }}
      >
        Preparación lingüística · TEF / TCF Canada
      </div>
    </AbsoluteFill>
  );
};

export const PathwayFilm = () => {
  const t = useAuthoredFrames();
  return (
    <AbsoluteFill style={{ fontFamily: "DM Sans" }}>
      <style>
        {["Outfit", "DM Sans"]
          .flatMap((family) =>
            [400, 500, 600, 700].map(
              (w) =>
                `@font-face{font-family:'${family}';font-style:normal;font-weight:${w};src:url('${staticFile(`${family.replace(" ", "-")}-${w}.ttf`)}') format('truetype');}`,
            ),
          )
          .join("\n")}
      </style>
      <Sequence from={0} durationInFrames={t(102)}>
        <Opening />
      </Sequence>
      <Sequence from={t(102)} durationInFrames={t(138)}>
        <Assessment />
      </Sequence>
      <Sequence from={t(240)} durationInFrames={t(150)}>
        <Route />
      </Sequence>
      <Sequence from={t(390)} durationInFrames={t(150)}>
        <Week />
      </Sequence>
      <Sequence from={t(540)} durationInFrames={t(120)}>
        <Website />
      </Sequence>
      <Sequence from={t(660)} durationInFrames={t(150)}>
        <Outro />
      </Sequence>
      <Audio src={staticFile("soundtrack.wav")} volume={0.65} />
    </AbsoluteFill>
  );
};
