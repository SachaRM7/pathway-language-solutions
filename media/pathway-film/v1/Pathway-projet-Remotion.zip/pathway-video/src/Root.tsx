import React from "react";
import { Composition } from "remotion";
import { PathwayFilm } from "./PathwayFilm";
import "./fonts";
export const Root: React.FC = () => (
  <Composition
    id="PathwayPresentation"
    component={PathwayFilm}
    durationInFrames={1620}
    fps={60}
    width={1920}
    height={1080}
  />
);
