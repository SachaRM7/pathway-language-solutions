import { continueRender, delayRender, staticFile } from "remotion";
const handle = delayRender("Loading local Pathway typefaces");
Promise.all(
  ["Outfit", "DM Sans"].flatMap((family) =>
    [400, 500, 600, 700].map(async (weight) => {
      const font = new FontFace(
        family,
        `url(${staticFile(`${family.replace(" ", "-")}-${weight}.ttf`)})`,
        { weight: String(weight) },
      );
      const loaded = await font.load();
      document.fonts.add(loaded);
    }),
  ),
).then(() => continueRender(handle));
