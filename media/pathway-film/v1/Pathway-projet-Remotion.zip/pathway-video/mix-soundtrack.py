from pathlib import Path
import subprocess,wave,array
root=Path(__file__).resolve().parent
sr=48000
mix=array.array('f',[0])*(sr*27*2)
cues=[('mouse-click',2.53,.5),('whoosh',3.30,.28),('switch',4.1,.3),('switch',4.4,.3),('switch',4.7,.3),('whoosh',7.94,.28),('page-turn',8.55,.25),('page-turn',8.81,.25),('page-turn',9.08,.25),('page-turn',9.35,.25),('whoosh',12.94,.28),('switch',13.4,.24),('switch',13.77,.24),('switch',14.13,.24),('switch',14.5,.24),('whoosh',17.94,.28),('ding',22.38,.25),('switch',23.12,.24)]
for name,at,vol in cues:
 data=subprocess.check_output(['ffmpeg','-v','error','-i',str(root/'public'/'sfx'/f'{name}.wav'),'-f','f32le','-ar',str(sr),'-ac','2','-'])
 values=array.array('f');values.frombytes(data);offset=int(at*sr)*2
 for i,v in enumerate(values[:len(mix)-offset]):mix[offset+i]+=v*vol
pcm=array.array('h',(int(max(-.95,min(.95,v))*32767) for v in mix))
with wave.open(str(root/'public'/'soundtrack.wav'),'wb') as w:w.setnchannels(2);w.setsampwidth(2);w.setframerate(sr);w.writeframes(pcm.tobytes())
print('27s stereo soundtrack, peak:',max(abs(v) for v in mix))
