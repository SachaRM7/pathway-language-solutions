# Pathway — vidéo de présentation

Première version en espagnol, 27 secondes, 1920 × 1080, 60 images/seconde.
Animations React/Remotion, capture réelle du site et bruitages discrets. Sans voix off ni musique.

## Lancer et exporter

Node.js 20+ et npm sont nécessaires.

```bash
npm ci
npm run dev
npm run check
npm run render
```

La composition s'appelle `PathwayPresentation`. L'export est écrit dans `out/pathway-presentation-es.mp4`.
Le premier rendu télécharge Chrome Headless Shell. Les visuels, polices et sons sont ensuite locaux.

## Montage

| Temps | Scène |
|---|---|
| 0–3,4 s | Objectif NCLC 7, texte saisi puis transition |
| 3,4–8 s | Évaluation du niveau, résultat illustratif identifié « EJEMPLO » |
| 8–13 s | Parcours A1 → A2 → B1 → B2 ; objectif NCLC 7 |
| 13–18 s | Semaine illustrative : cours, pratique, feedback |
| 18–22 s | Capture réelle du site et modalités d'accompagnement |
| 22–27 s | Marque et appel à l'évaluation gratuite |

Le parcours dépend du niveau de départ. La présentation ne promet ni délai garanti, ni réussite automatique, ni résultat migratoire. Les barres du résultat illustratif sont graphiques : elles ne représentent pas un score officiel.

## Modifier

- `src/PathwayFilm.tsx` : textes, couleurs, scènes, cadrages.
- `src/Root.tsx` : résolution, durée, fps.
- `src/timing.ts` : timeline écrite à 30 fps et rendue à 60 fps.
- `public/hero.jpg` : capture réelle de la page d'accueil espagnole.
- `public/pathway-mark.svg` : logo existant de Pathway.
- `public/soundtrack.wav` : piste stéréo de 27 s.
- `synthesize-sfx.py` et `mix-soundtrack.py` : reproduction des bruitages et de leur montage (Python, NumPy, FFmpeg). Les sons déjà produits sont fournis ; Python n'est pas nécessaire pour exporter la vidéo.

## Sources et filiation

Consultation le 16 septembre 2026 :
- https://pathway-languages.com/ — contenu commercial, capture de la page d'accueil, logo.
- https://github.com/SachaRM7/pathway-language-solutions — identité et CSS `pathway-v3.css`, palette `brand-palette`, Outfit et DM Sans.
- https://github.com/Nutlope/inspo/tree/main/teaser — base Remotion, dépendances verrouillées, `timing.ts`, principe d'ouverture tapée / pression / zoom et découpage en séquences. Commit `85acb10f42e433b696fd95a447baf4d47d11021d`.

Les scènes Pathway sont une adaptation spécifique. Aucun exemple de site tiers du montage Inspo n'est incorporé. Les bruitages de la version Pathway sont synthétisés localement : les fichiers son distants du projet original n'étaient pas accessibles ici. La licence MIT d'Inspo est conservée dans `LICENSE-Inspo`.
Les droits de la marque, du logo et de la capture Pathway restent ceux de leurs titulaires. Polices Google Fonts : Outfit et DM Sans, licences SIL Open Font License jointes.

## Vérification

Contrôle TypeScript, rendu MP4 complet, inspection d'images de chaque scène, dimensions/durée/audio vérifiées avec FFprobe. La capture publique fige le site à la date du montage.
