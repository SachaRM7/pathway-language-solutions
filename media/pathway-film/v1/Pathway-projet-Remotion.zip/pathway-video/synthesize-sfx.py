from pathlib import Path
import numpy as np,wave
root=Path(__file__).resolve().parent/'public'/'sfx';root.mkdir(exist_ok=True)
sr=48000;rng=np.random.default_rng(42)
for name,duration in [('whoosh',.43),('mouse-click',.055),('switch',.095),('ding',.65),('page-turn',.16)]:
 t=np.arange(int(duration*sr))/sr
 if name=='ding': y=(np.sin(2*np.pi*880*t)+.3*np.sin(2*np.pi*1760*t))*np.exp(-t*8)*(1-np.exp(-t*180))*.23
 elif name=='whoosh':
  raw=rng.normal(0,1,len(t)); y=np.convolve(raw,np.ones(20)/20,mode='same')*np.sin(np.pi*t/duration)**2*.7
 elif name=='page-turn': y=rng.normal(0,1,len(t))*np.exp(-t*35)*(1-np.exp(-t*400))*.15
 else: y=(np.sin(2*np.pi*(1100 if name=='switch' else 700)*t)+rng.normal(0,.15,len(t)))*np.exp(-t*85)*(1-np.exp(-t*2000))*.3
 stereo=np.column_stack((y,y));pcm=(np.clip(stereo,-1,1)*32767).astype('<i2')
 with wave.open(str(root/(name+'.wav')),'wb') as w:w.setnchannels(2);w.setsampwidth(2);w.setframerate(sr);w.writeframes(pcm.tobytes())
print('Generated 5 original subtle effects')
